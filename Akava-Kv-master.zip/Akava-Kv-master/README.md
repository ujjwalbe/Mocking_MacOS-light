# Akava-Kv
![](https://i.imgur.com/IFLK03X.png)
User oriented Kvantum theme

## How to use
1. Download the main branch and extract it to a folder.
2. Use the Kvantum Manager and select the folder (Akava-Kv-master/Akava-Kv) with extracted theme.
3. Click on "Install this theme" and "Use this theme" in "Change/Delete Theme"

## Recommendation
Use [Breeze-Blurred](https://github.com/alex47/BreezeBlurred) and [Akava colors](https://github.com/Akava-Design/Akava-Colors)

## Warning
Early development. Currently is alpha.
